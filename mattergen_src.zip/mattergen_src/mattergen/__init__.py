# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
__version__ = "1.0.0"
