Código fuente de MatterGen v1.0.3 (github.com/microsoft/mattergen, licencia MIT, ver LICENSE).

Por qué está aquí: el paquete instalado en el kernel Python-AI-Materials de Kabré
no incluye los archivos de datos sampling_conf/ ni common/gemnet/gemnet-dT.json,
y sin ellos mattergen-generate falla. Los notebooks 03 y sol_dia3 ponen esta
carpeta primero en el PYTHONPATH al llamar a MatterGen. Es la misma versión (1.0.3)
que la instalada, así que las dependencias coinciden.

Los pesos de los modelos NO están aquí (≈2 GB): se copian en /work/$USER/hf_cache.
